<?php
// ustalamy ścieżkę do katalogu, którego zawartość chcemy odczytać
$path = 'katalogtestowy';

// tworzymy pustą tablicę, w której będziemy przechowywać nazwy katalogów
$directories = array();

// tworzymy pustą tablicę, w której będziemy przechowywać nazwy plików
$files = array();

// odczytujemy zawartość katalogu
if ($handle = opendir($path)) {
    while (false !== ($entry = readdir($handle))) {
        // pomijamy elementy . i ..
        if ($entry == '.' || $entry == '..') {
            continue;
        }

        // sprawdzamy, czy dany element jest katalogiem czy plikiem
        if (is_dir($path.'/'.$entry)) {
            $directories[] = $entry;
        } elseif (is_file($path.'/'.$entry)) {
            $files[] = $entry;
        }
    }
    closedir($handle);
}

// sortujemy nazwy katalogów alfabetycznie
sort($directories);

// sortujemy nazwy plików alfabetycznie
sort($files);

// wyświetlamy wszystkie katalogi
foreach ($directories as $directory) {
    echo '<div>'.$directory.'</div>';
}

// wyświetlamy wszystkie pliki
foreach ($files as $file) {
    echo '<div>'.$file.'</div>';
}
?>
