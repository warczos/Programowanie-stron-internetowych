<?php
// losujemy 20 liczb z przedziału od 1 do 100 i zapisujemy je do pliku
$filename = 'zadanie3.txt';
$numbers = array();
for ($i = 0; $i < 20; $i++) {
    $number = rand(1, 100);
    $numbers[] = $number;
}
file_put_contents($filename, implode("\n", $numbers));

// odczytujemy zawartość pliku z liczbami
$content = file_get_contents($filename);

// dzielimy zawartość na linie i przetwarzamy każdą liczbę
$lines = explode("\n", $content);
$even_numbers = array();
$sum = 0;
foreach ($lines as $line) {
    $number = (int)$line;
    if ($number % 2 == 0) {
        $even_numbers[] = $number;
        $sum += $number;
    }
}

// zapisujemy sumę liczb parzystych do pliku
$result_filename = 'wyniki.txt';
file_put_contents($result_filename, 'Suma liczb parzystych: '.$sum);

// wyświetlamy tylko liczby parzyste
foreach ($even_numbers as $number) {
    echo $number.'<br>';
}
?>
