<?php
// Otwórz plik
$file = fopen('zadanie4.txt', 'r');

// Zainicjuj tablicę asocjacyjną
$data = array();

// Odczytaj plik wiersz po wierszu
while ($line = fgets($file)) {
    // Podziel wiersz na imię i nazwisko
    $name = explode(' ', $line);
    // Dodaj imię i nazwisko do tablicy asocjacyjnej
    $data[] = array('first_name' => $name[0], 'last_name' => $name[1]);
}

// Posortuj dane według nazwisk
usort($data, function($a, $b) {
    return $a['last_name'] <=> $b['last_name'];
});

// Zapisz posortowane dane do pliku
$file = fopen('posortowane.txt', 'w');
foreach ($data as $item) {
    fwrite($file, $item['first_name'] . ' ' . $item['last_name'] . "\n");
}

// Wyświetl posortowane nazwiska w przeglądarce
foreach ($data as $item) {
    echo $item['first_name'] . ' ' . $item['last_name'] . '<br>';
}
