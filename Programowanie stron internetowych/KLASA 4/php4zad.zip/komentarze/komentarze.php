<?php
// ścieżka do pliku z komentarzami
$filename = 'komentarze.txt';

// jeśli formularz został przesłany, to zapisujemy nowy komentarz do pliku
if (isset($_POST['comment'])) {
    $comment = $_POST['comment'];
    $handle = fopen($filename, 'a');
    fwrite($handle, $comment."\n");
    fclose($handle);
}

// odczytujemy zawartość pliku z komentarzami i przechowujemy ją w tablicy
$comments = array();
if (file_exists($filename)) {
    $handle = fopen($filename, 'r');
    while (!feof($handle)) {
        $comment = fgets($handle);
        if ($comment !== false) {
            $comments[] = $comment;
        }
    }
    fclose($handle);
}

// jeśli nie ma żadnych komentarzy, to wyświetlamy odpowiedni komunikat
if (empty($comments)) {
    echo 'Brak komentarzy';
} else {
    // jeśli są jakieś komentarze, to wyświetlamy je w pętli foreach
    foreach ($comments as $comment) {
        echo '<div>'.$comment.'</div>';
    }
}

// wyświetlamy formularz umożliwiający dodanie nowego komentarza
echo '<form method="post">';
echo '<textarea name="comment"></textarea>';
echo '<br>';
echo '<input type="submit" value="Dodaj komentarz">';
echo '</form>';
?>
